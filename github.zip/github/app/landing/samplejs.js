/**
 * Created by Ashish on 9/20/2016.
 */
function updatedata(data) {
    document.getElementById("qrcode").value = data;
    console.log(data);
    
    //js script 
    
    };
